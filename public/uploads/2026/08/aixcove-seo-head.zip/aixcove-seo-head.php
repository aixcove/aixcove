<?php
/**
 * Plugin Name: AixCove SEO Head
 * Description: Inject meta description and OG tags into head since Rank Math setup is incomplete.
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'wp_head', function() {
    if ( is_singular( 'post' ) ) {
        $post_id = get_the_ID();
        $excerpt = get_the_excerpt( $post_id );
        $title = get_the_title( $post_id );
        $url = get_permalink( $post_id );
        $thumb = get_the_post_thumbnail_url( $post_id, 'full' );
        
        if ( $excerpt ) {
            $desc = wp_strip_all_tags( $excerpt );
            $desc = wp_trim_words( $desc, 30, '' );
            echo '<meta name="description" content="' . esc_attr( $desc ) . '" />' . "\n";
        }
        
        // Open Graph
        echo '<meta property="og:type" content="article" />' . "\n";
        echo '<meta property="og:title" content="' . esc_attr( $title ) . '" />' . "\n";
        if ( isset( $desc ) ) {
            echo '<meta property="og:description" content="' . esc_attr( $desc ) . '" />' . "\n";
        }
        echo '<meta property="og:url" content="' . esc_url( $url ) . '" />' . "\n";
        if ( $thumb ) {
            echo '<meta property="og:image" content="' . esc_url( $thumb ) . '" />' . "\n";
        }
        echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '" />' . "\n";
        if ( isset( $desc ) ) {
            echo '<meta name="twitter:description" content="' . esc_attr( $desc ) . '" />' . "\n";
        }
    } elseif ( is_front_page() || is_home() ) {
        echo '<meta name="description" content="AI X Cove is the best AI tools directory for 2026. Discover, compare, and choose the right AI tools for coding, content creation, marketing, and business automation." />' . "\n";
        echo '<meta property="og:type" content="website" />' . "\n";
        echo '<meta property="og:title" content="AI X Cove – Best AI Tools Directory for 2026" />' . "\n";
        echo '<meta property="og:description" content="Discover, compare, and choose the right AI tools for coding, content creation, marketing, and business automation." />' . "\n";
        echo '<meta property="og:url" content="' . esc_url( home_url() ) . '" />' . "\n";
        echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
    }
}, 1 );
